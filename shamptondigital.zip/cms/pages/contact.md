---
title: Contact
permalink: '{{ page.fileSlug }}/index.html'
layout: contact.html
slug: contact
tags: pages
seo:
  noindex: false
  title: Contact | Lethbridge Web Design
  description: Have a different question for Hampton Designs? Send us a message here!
  og:title: Contact | Lethbridge Web Design
  additional_tags: >-
    <meta content="Have a different question for Hampton Designs? Send us a
    message here!" property="og:description"><meta content="Have a different
    question for Hampton Designs? Send us a message here!"
    property="twitter:description"><meta property="og:type" content="website">
  twitter:title: Contact | Lethbridge Web Design
---


