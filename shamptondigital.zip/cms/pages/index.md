---
title: Home
permalink: index.html
layout: index.html
slug: ''
tags: pages
seo:
  noindex: false
  title: Websites Made Simple | Lethbridge Web Design
  description: >-
    Get a new site on-time and on-budget! Hampton Designs is a Lethbridge web
    design company here to help you save time & stress.
  og:title: Websites Made Simple | Lethbridge Web Design
  additional_tags: >-
    <meta content="Get a new site on-time and on-budget! Hampton Designs is a
    Lethbridge web design company here to help you save time &amp; stress."
    property="og:description"><meta content="Get a new site on-time and
    on-budget! Hampton Designs is a Lethbridge web design company here to help
    you save time &amp; stress." property="twitter:description"><meta
    content="https://uploads-ssl.webflow.com/63ee6d8b12a1ffaabe69a12c/640b9c4add97ee6a5b975e63_6266e4367a3461852f72405a_OG%20(1).webp"
    property="twitter:image"><meta property="og:type" content="website">
  og:image: >-
    https://uploads-ssl.webflow.com/63ee6d8b12a1ffaabe69a12c/640b9c4add97ee6a5b975e63_6266e4367a3461852f72405a_OG%20(1).webp
  twitter:title: Websites Made Simple | Lethbridge Web Design
---


