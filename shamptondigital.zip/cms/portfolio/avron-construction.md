---
title: Avron Construction
slug: avron-construction
updated-on: '2023-03-11T02:13:26.331Z'
created-on: '2023-03-10T00:45:30.294Z'
published-on: '2023-03-11T02:13:37.565Z'
f_project-description: >-
  Avron Construction needed a website to establish an online presence. We worked
  together to produce a creative final design that included all the information
  that a potential customer might want to know.
f_project-image-1:
  url: >-
    /assets/external/640be3c47c91e03297bbc2ea_640be3a17c91e0d837bbc224_group202393.webp
  alt: null
f_water-mark-color: '#e37725'
f_short-description: >-
  Avron Construction needed a website to establish an online presence. We worked
  together to...
f_url: https://www.avronconstruction.ca/
layout: '[portfolio].html'
tags: portfolio
---


