---
title: Calgary Police Rodeo
slug: calgary-police-rodeo
updated-on: '2023-03-10T18:22:36.668Z'
created-on: '2023-03-10T00:40:54.482Z'
published-on: '2023-03-10T18:42:01.246Z'
f_project-description: >-
  The Calgary Police Rodeo was in urgent need of a website. They needed
  something fresh and modern, and they needed it fast. They gave me the
  parameters and in a month we had a site built that exceeded all of their
  expectations!
f_project-image-1:
  url: >-
    /assets/external/640a7cbea23599664e33968a_640a7ca9e86686a121200848_group202391.webp
  alt: null
f_water-mark-color: '#d42a30'
f_short-description: >-
  The Calgary Police Rodeo was in urgent need of a website. They needed
  something fresh and modern...
f_url: https://www.calgarypolicerodeo.com/
layout: '[portfolio].html'
tags: portfolio
---


