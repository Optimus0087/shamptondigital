---
f_water-mark-color: '#0a66cf'
title: Island Lake Christian Retreat Centre
slug: island-lake-christian-retreat-centre
updated-on: '2023-03-10T18:23:13.002Z'
created-on: '2023-03-09T23:37:45.261Z'
published-on: '2023-03-10T18:42:01.246Z'
f_project-description: >-
  Island Lake is a camp in the Crowsnest Pass that runs events and offers groups
  a rental venue. My goal was to build a website that reflected both operations.
  The site had to have a people focus and easy for them to update and edit
  themselves too.
f_project-image-1:
  url: >-
    /assets/external/640a7a3ba235998563336215_640a7a074b2b0704dc94091c_group202390204.webp
  alt: null
f_short-description: >-
  Island Lake is a camp in the Crowsnest Pass that runs events and offers groups
  a rental venue. My...
f_url: https://www.ilcrc.ca/
layout: '[portfolio].html'
tags: portfolio
---


